create view s1(count) as
SELECT count(*) AS count
FROM people;

alter table s1
    owner to s291485;

