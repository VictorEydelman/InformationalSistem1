create function check_project_scientific_supervisor() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT 1 From "user" u where id=NEW.scientific_supervisor_user_id and Role_scientific_supervisor=true) THEN
        RAISE EXCEPTION 'The user cannot be a supervisor, as he does not have the appropriate roles';
    END IF;
    RETURN NEW;
END
$$;

alter function check_project_scientific_supervisor() owner to s291485;

