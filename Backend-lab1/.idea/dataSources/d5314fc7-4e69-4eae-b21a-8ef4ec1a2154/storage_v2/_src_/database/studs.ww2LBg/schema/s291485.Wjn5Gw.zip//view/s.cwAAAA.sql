create view s(count) as
SELECT count(*) AS count
FROM condition;

alter table s
    owner to s291485;

