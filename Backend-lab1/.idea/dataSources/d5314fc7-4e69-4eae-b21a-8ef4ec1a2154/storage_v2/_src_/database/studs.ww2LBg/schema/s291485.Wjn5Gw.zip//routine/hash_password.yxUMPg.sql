create function hash_password() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF NEW.password IS DISTINCT FROM OLD.password THEN
            NEW.password := md5(NEW.password);
        END IF;
        RETURN NEW;
    END;
$$;

alter function hash_password() owner to s291485;

