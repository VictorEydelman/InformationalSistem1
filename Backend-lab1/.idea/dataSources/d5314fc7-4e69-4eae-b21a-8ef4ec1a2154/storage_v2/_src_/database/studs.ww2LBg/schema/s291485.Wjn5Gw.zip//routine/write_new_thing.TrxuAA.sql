create function write_new_thing() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'INSERT into Thing: Thing %, id_people %, looks_like %, nickname %.',
        new.THING, new.ID_PEOPLE, new.LOOKS_LIKE, new.NICKNAME;
    RETURN NEW;
END;
$$;

alter function write_new_thing() owner to s291485;

