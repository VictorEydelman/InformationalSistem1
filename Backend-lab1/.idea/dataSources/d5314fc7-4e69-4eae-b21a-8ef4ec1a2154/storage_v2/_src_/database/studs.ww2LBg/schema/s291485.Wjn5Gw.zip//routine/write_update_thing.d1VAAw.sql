create function write_update_thing() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'UPDATE into Thing: Thing %, id_people %, looks_like %, nickname %.',
        new.THING, new.ID_PEOPLE, new.LOOKS_LIKE, new.NICKNAME;
    RETURN NEW;
END;
$$;

alter function write_update_thing() owner to s291485;

