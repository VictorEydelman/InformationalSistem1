create function ma() returns integer
    language sql
as
$$
    select 1 as result
$$;

alter function ma() owner to s291485;

