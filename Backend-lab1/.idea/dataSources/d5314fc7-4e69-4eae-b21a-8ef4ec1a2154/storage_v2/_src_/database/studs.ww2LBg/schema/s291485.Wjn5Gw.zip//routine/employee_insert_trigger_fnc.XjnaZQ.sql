create function employee_insert_trigger_fnc() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO Condition(name_thing, condition)
    VALUES(new.thing,'');
    RETURN NEW;
END
$$;

alter function employee_insert_trigger_fnc() owner to s291485;

