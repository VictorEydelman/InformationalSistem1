create view sq(name_thing, condition) as
SELECT name_thing,
       condition
FROM condition;

alter table sq
    owner to s291485;

