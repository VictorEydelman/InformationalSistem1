create function ship_type_delete_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'DELETE on Thing: Thing %, id_people %, looks_like %, nickname %.',
        old.THING, old.ID_PEOPLE, old.LOOKS_LIKE, old.NICKNAME;
    RETURN OLD;
END;
$$;

alter function ship_type_delete_trigger() owner to s291485;

