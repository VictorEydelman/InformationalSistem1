create function thing_to_condition() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO Condition(name_thing, condition)
    VALUES('','');
    RETURN NEW;
END
$$;

alter function thing_to_condition() owner to s291485;

