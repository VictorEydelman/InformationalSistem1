create function ship_type_insert_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'INSERT: Thing with Thing %, Type %, Capacity %, Max Speed %.',
        new.THING, new.ID_PEOPLE, new.LOOKS_LIKE, new.NICKNAME;
    RETURN NEW;
END;
$$;

alter function ship_type_insert_trigger() owner to s291485;

