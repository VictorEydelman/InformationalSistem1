create function qship_type_delete_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'DELETE on Thing: Thing %, id_people %, looks_like %, nickname %.',
        new.THING, new.ID_PEOPLE, new.LOOKS_LIKE, new.NICKNAME;
    RETURN new;
END;
$$;

alter function qship_type_delete_trigger() owner to s291485;

