create function thing_insert_trigger_fnc() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO Condition(name_thing, condition)
    VALUES('','');
    RETURN NEW;
END
$$;

alter function thing_insert_trigger_fnc() owner to s291485;

