create function givename() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.last_modified = current_date || ' ' || current_time;
    RETURN NEW;
END;
$$;

alter function givename() owner to s291485;

