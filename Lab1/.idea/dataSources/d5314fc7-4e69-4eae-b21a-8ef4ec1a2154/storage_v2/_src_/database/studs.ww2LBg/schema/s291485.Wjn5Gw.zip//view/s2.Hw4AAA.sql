create view s2(count) as
SELECT count(*) AS count
FROM people;

alter table s2
    owner to s291485;

